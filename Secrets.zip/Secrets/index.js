import express from 'express';
import ejs from 'ejs';
import axios from 'axios';

const app=express();
const port=3000;

app.use(express.static("public"))

app.get("/",(req,res)=>{
    res.render("index.ejs",{secret:"Secrets on the way....", user:""});
})

app.post("/submit", async (req,res)=>{
    try {
        const get_data= await axios.get("https://secrets-api.appbrewery.com/random") ;
        console.log(get_data.data);
        
        const data=
        res.render("index.ejs", {
            secret:get_data.data.secret,
            user:get_data.data.username
        })
    } catch (error) {
        res.render("index.js",{secret:error.response.data})
    }
})

app.listen(port,()=>{
    console.log(`server running at port ${port}`);
})